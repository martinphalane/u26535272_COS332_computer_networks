#!/bin/bash
java -cp /usr/lib/cgi-bin RandomLinks
